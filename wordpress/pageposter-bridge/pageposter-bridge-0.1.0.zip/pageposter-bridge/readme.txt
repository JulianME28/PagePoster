=== PagePoster Bridge ===
Contributors: pageposter
Requires at least: 5.6
Requires PHP: 8.0
Stable tag: 0.1.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html

Authenticated static PagePoster page/post storage with durable operation identities and atomic conditional updates.

== Installation ==
Build using Node: node wordpress/pageposter-bridge/build-zip.cjs
Install and activate the supplied PagePoster Clean Links ZIP first.
Upload pageposter-bridge-0.1.0.zip in WordPress Plugins > Add New > Upload Plugin, then activate it.
Single-site WordPress, HTTPS, PHP 8.0+, mysqli/mysqlnd, DOM, standard database configuration and InnoDB tables are required.
The database account must directly demonstrate TRIGGER or ALL privileges for the posts and both Bridge tables before trigger absence can be trusted.
Role-only grants, partial revokes and ambiguous database wildcard grants are unsupported. For database-level names containing _ or %, use explicitly escaped literal scope, or exact table grants. The plugin never changes database grants.
Use an Application Password for an account with unfiltered_html plus the exact create/edit/publish permissions needed.
No remote installation, no arbitrary PHP execution, no plugin installation endpoint and no credentials are stored by this plugin.

== Scope ==
Only Bridge-created posts in the managed registry can be changed. The content must contain one real div with the exact id pp-landing.
The plugin does not adopt or rewrite unrelated existing pages, change WordPress settings, activate plugins, or remove robots directives.
The static write path bypasses WordPress save/transition hooks, taxonomy defaults, sanitization and standard revision creation.
Previous raw snapshots are retained in the Bridge operation ledger. There is no automatic restore endpoint.
Public rendering, plugin compatibility, caches and outbound links must be checked after a committed write.
This build has PHP unit/contract tests. A live WordPress/MySQL concurrent-write pilot has not yet been run.

== API ==
REST namespace: pageposter/v1
GET status
POST operations
GET operations/{operationId}
GET pages/{postId}
Every endpoint requires HTTPS and verified Application Password authentication.
Keep the same operationId and identical payload during reconciliation. Never change the operationId merely because a response timed out.
A GET operation 404 can also mean its transaction is still in flight.
The operation result is historical. Later manual saves may differ; read the page snapshot before the next change.

== Retention ==
Deactivation and removal retain the two Bridge tables. Deleting the ledger removes idempotency history and must not be done while old operations may be retried.

== Changelog ==
= 0.1.0 =
Initial static-content Bridge. Application Password permissions, explicit operation ledger, InnoDB compare-and-swap and exact-byte readback.
